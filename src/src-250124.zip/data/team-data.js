
// team member img import here 
import avatar_img_1 from "@assets/img/team/team-5.jpg";
import avatar_img_2 from "@assets/img/team/team-1.jpg";
import avatar_img_3 from "@assets/img/team/team-2.jpg";
import avatar_img_4 from "@assets/img/team/team-3.jpg";
import avatar_img_5 from "@assets/img/team/team-4.jpg";


const team_data = [
    {
        id: 1,
        img: avatar_img_1,
        name: "Alextina Ditarson",
        job_title: "App Developer",
    },
    {
        id: 2,
        img: avatar_img_2,
        name: "Leslie Alexander",
        job_title: "Web Developer",
    },
    {
        id: 3,
        img: avatar_img_3,
        name: "Brooklyn Simmons",
        job_title: "Game Developer",
    },
    {
        id: 4,
        img: avatar_img_4,
        name: "Marvin McKinney",
        job_title: "Website Developer",
    },
    {
        id: 5,
        img: avatar_img_5,
        name: "Kathryn Murphy",
        job_title: "GRAPHIC DESIGNER",
    },
    {
        id: 6,
        img: avatar_img_1,
        name: "Alextina Ditarson",
        job_title: "App Developer",
    },
    {
        id: 7,
        img: avatar_img_2,
        name: "Leslie Alexander",
        job_title: "Web Developer",
    },
    {
        id: 8,
        img: avatar_img_3,
        name: "Brooklyn Simmons",
        job_title: "Game Developer",
    },
    {
        id: 9,
        img: avatar_img_4,
        name: "Marvin McKinney",
        job_title: "Website Developer",
    },
    {
        id: 10,
        img: avatar_img_5,
        name: "Kathryn Murphy",
        job_title: "GRAPHIC DESIGNER",
    },
]
export default team_data